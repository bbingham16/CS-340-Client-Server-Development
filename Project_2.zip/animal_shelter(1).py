from pymongo import MongoClient
from bson.objectid import ObjectId
import json

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """ 
    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        #self.client = MongoClient('mongodb://localhost:33549')
        ## with authentication
        self.client = MongoClient('mongodb://%s:%s@localhost:33549/?authMechanism=DEFAULT&authSource=AAC' % (username, password))
        # where xxxx is your unique port numberS
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary      
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
    def read(self,data):
        cursor = self.database.animals.find(data, {'_id':False})
        return cursor
        
# Create method to implement the R in CRUD. 
    def read_all(self, data):
        if data is not None:
            global globalRead
            globalRead = self.database.animals.find_one(data, {'_id':False})
            return globalRead
        else:
            raise Exception("Nothing to save, because data parameter is empty")
        
# Complete this create method to implement the U in CRUD.
    def update(self, data, update_info, data_test):
        if data is not None:
            localUpdate = self.database.animals.update_one(data, update_info)
            global globalUpdate
            globalUpdate = self.database.animals.find_one(data_test, {'_id':False})
            return globalUpdate
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
# Complete this create method to implement the D in CRUD.
    def delete_one(self, data_Delete):
        if data_Delete is not None:
            global globalDelete
            globalDelete = self.database.animals.delete_one(data_Delete)
            return globalDelete
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
# Returning global read value            
    def globalReadFunc(self):
        return globalRead
    
# Returning global update value    
    def globalUpdateFunc(self):
        return globalUpdate
    
# Returning global delete value    
    def globalDeleteFunc(self):
        return globalDelete

